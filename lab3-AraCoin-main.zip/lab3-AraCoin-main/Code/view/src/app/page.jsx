'use client';

import { MantineProvider } from '@mantine/core';
import Layout from "@/components/applayout/layout";
import '@mantine/core/styles.css';

function home() {
  return (
    <MantineProvider>
        <div>
          {/* r20*/}
          <h1>Bem-vindo ao Aracoin!</h1>
          {/* r21*/}
        </div>
      </MantineProvider>
  );
}


export default home
