# lab3-AraCoin
Repositório do laboratório da matéria "Laboratório de Desenvolvimento de Software", no qual será criada uma aplicação de sistema de recompensas de professores para alunos de uma universidade
